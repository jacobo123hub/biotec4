import { useState } from 'react';

function App() {
  const [connected, setConnected] = useState(false);

  const connectToESP32 = async () => {
    try {
      const device = await navigator.bluetooth.requestDevice({
        acceptAllDevices: true,
        optionalServices: ['battery_service'],
      });
      setConnected(true);
      console.log("Conectado a:", device.name);
    } catch (error) {
      console.log("Error:", error);
    }
  };

  return (
    <div className="text-center p-10">
      <h1 className="text-3xl font-bold">Sistema de Riego Automático</h1>
      <button 
        onClick={connectToESP32} 
        className="mt-5 px-5 py-2 bg-blue-500 text-white rounded-lg"
      >
        {connected ? "Conectado" : "Conectar Bluetooth"}
      </button>
    </div>
  );
}

export default App;